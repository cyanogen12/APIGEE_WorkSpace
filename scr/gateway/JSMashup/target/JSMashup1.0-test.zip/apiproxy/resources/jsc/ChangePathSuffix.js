 url =context.getVariable("target.url");
 
 var newurl=url+"/get"
 
 context.setVariable("target.url",newurl);