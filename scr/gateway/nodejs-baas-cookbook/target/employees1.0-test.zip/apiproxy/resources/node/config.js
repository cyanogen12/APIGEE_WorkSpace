/*
 * Edit the defaults for your environment
 */

exports.organization = 'cyanogen'
exports.application = 'employees'
exports.clientId = 'YXA6dCULDUqQEeeR8Aq4dBoSnA'
exports.clientSecret = 'YXA6bZbvBD3Xk7SHG2wV7AkmWW9biSA'
exports.tokenExpiration = 60000
exports.logging = true
